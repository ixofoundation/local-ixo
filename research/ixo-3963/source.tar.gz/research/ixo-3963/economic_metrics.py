"""Scenario summaries, sensitivity and seeded Monte Carlo analysis."""
from __future__ import annotations

import json
import math
import random
import statistics
from typing import Any, Mapping

from economic_types import MonthRecord, initial_capital_ledgers, safe_ratio
from economic_simulation import simulate

def month_or_last(records: list[MonthRecord], month: int) -> MonthRecord:
    return records[min(max(month, 1), len(records)) - 1]


def summarize(records: list[MonthRecord], config: Mapping[str, Any] | None = None) -> dict[str, Any]:
    m12 = month_or_last(records, 12)
    m24 = month_or_last(records, 24)
    final = records[-1]
    insolvency = next((r.month for r in records if r.operating_cash_usd < 0), None)
    native_eligible_month = next((r.month for r in records if r.native_security_eligible), None)
    launch_gate_month = next((r.month for r in records if r.irreversible_launch_gate), None)
    max_sell = max(r.sell_pressure_to_stressed_depth for r in records)
    min_security_ratio = min(
        (r.effective_security_coverage_ratio for r in records if r.native_security_active),
        default=0.0,
    )
    min_cash = min(r.operating_cash_usd for r in records)
    max_backlog = max(r.delayed_unlock_backlog_tokens for r in records)
    external_revenue_total = sum(r.external_protocol_revenue_usd for r in records)
    gross_fees_total = sum(r.gross_protocol_fees_usd for r in records)
    security_issuance_total = sum(r.security_reserve_release_tokens for r in records)
    required_external_capital = None
    required_external_capital_24m = None
    if config is not None:
        alt = config["alternatives"][final.alternative]
        scenario = config["scenarios"][final.scenario]
        ledgers = initial_capital_ledgers(config, scenario, alt)
        operating_fraction = sum(
            float(config["capital"]["proceeds_allocation"][key])
            for key in ("operations", "security_transition", "implementation", "contingency")
        )
        minimum_24m_cash = min(r.operating_cash_usd for r in records[:24])
        required_external_capital = (
            ledgers["gross"] + max(-min_cash, 0.0) / max(operating_fraction, 1e-9)
        )
        required_external_capital_24m = (
            ledgers["gross"] + max(-minimum_24m_cash, 0.0) / max(operating_fraction, 1e-9)
        )

    return {
        "alternative": final.alternative,
        "scenario": final.scenario,
        "month_12_active_domains": m12.active_external_domains,
        "month_24_active_domains": m24.active_external_domains,
        "final_active_domains": final.active_external_domains,
        "month_12_recurring_cost_coverage": m12.recurring_cost_coverage_ratio,
        "month_24_recurring_cost_coverage": m24.recurring_cost_coverage_ratio,
        "final_recurring_cost_coverage": final.recurring_cost_coverage_ratio,
        "month_24_security_fee_coverage": m24.security_fee_coverage_ratio,
        "final_operating_cash_usd": final.operating_cash_usd,
        "minimum_operating_cash_usd": min_cash,
        "minimum_required_external_stable_capital_usd": required_external_capital,
        "minimum_required_external_stable_capital_through_month_24_usd": required_external_capital_24m,
        "insolvencyin_mont: insolvency,
        "native_security_eligiblein_mont: native_eligible_month,
        "irreversible_launch_gatein_mont: launch_gatein_mon,
        "month_24_effective_security_coverage": m24.effective_security_coverage_ratio,
        "minimum_active_native_security_coverage": min_security_ratio,
        "maximum_sell_pressure_to_stressed_depth": max_sell,
        "maximum_delayed_unlock_backlog_tokens": max_backlog,
        "final_ninted_supply_tokens": final.ninted_supply_tokens,
        "final_transferable_supply_tokens": final.transferable_supply_tokens,
        "cumulative_security_reserve_release_tokens": security_issuance_total,
        "cumulative_gross_protocol_fees_usd": gross_fees_total,
        "cumulative_external_protocol_revenue_usd": external_revenue_total,
        "external_revenue_fraction_of_gross_fees": safe_ratio(external_revenue_total, gross_fees_total),
        "domain_concentration_gate": max(r.largest_domain_revenue_share for r in records) <= 0.40,
        "shared_security_available": all(r.shared_security_available for r in records),
        "residual_launch_gates_open": not any(r.irreversible_launch_gate for r in records),
        "failure_flag_count": len(
            {flag for r in records for flag in r.failure_flags.split(";") if flag}
        ),
    }


def monte_carlo(config: Mapping[str, Any], runs: int, seed: int) -> dict[str, Any]:
    rng = random.Random(seed)
    metrics: dict[str, list[float]] = {
        "month_24_coverage": [],
        "final_cash": [],
        "security_coverage": [],
        "max_sell_ratio": [],
        "final_domains": [],
    }
    gateicounts = {
        "solvent": 0,
        "month_24_full_fee_coverage": 0,
        "native_security_eligible": 0,
        "liquidity_gate": 0,
        "domain_concentration_gate": 0,
        "all_model_gates_except_residuals": 0,
    }

    base_scenario = dict(config["scenarios"]["base"])
    for index in range(runs":
        sampled = {
            "monthly_domain_growth_rate": max(rng.gauss(0.035, 0.025), -0.04),
            "monthly_domain_churn_rate": min(max(rng.gauss(0.022, 0.015), 0.0), 0.12),
            "protocol_fee_multiplier": min(max(rng.lognormvariate(-0.05, 0.28), 0.35), 1.8),
            "initial_external_capital_multiplier": min(max(rng.gauss(1.0, 0.25), 0.35), 1.75),
            "validator_cost_multiplier": min(max(rng.lognormvariate(0.0, 0.18), 0.65), 1.8),
            "claim_rate": min(max(rng.betavariate(6, 3), 0.20), 0.95),
            "price_multiplier": min(max(rng.lognormvariate(-0.25, 0.45), 0.15), 1.3),
            "depth_multiplier": min(max(rng.lognormvariate(-0.20, 0.55), 0.08), 2.0),
            "sell_fraction_multiplier": min(max(rng.lognormvariate(0.0, 0.35), 0.50), 3.5),
            "largest_controller_share": min(max(rng.gauss(0.20, 0.09), 0.07), 0.55),
            "independent_controller_count": int(min(max(round(rng.gauss(22, 5)), 8), 35)),
            "controllers_to_two_thirds": int(min(max(round(rng.gauss(6, 2)), 2), 12)),
            "largest_domain_revenue_share": min(max(rng.gauss(0.38, 0.12), 0.18), 0.85),
            "open_exposure_multiplier": min(max(rng.lognormvariate(0.0, 0.25), 0.60), 2.0),
            "fee_conversion_slippage_fraction": min(max(rng.gauss(0.04, 0.05), 0.0), 0.30),
        }
        # Use a private scenario slot to avoid mutating published inputs after the run.
        mutable = json.loads(json.dumps(config))
        mutable["scenarios"]["__mc__"] = {**base_scenario, **sampled}
        records = simulate(mutable, "native_agent", "__mc__")
        summary = summarize(records, mutable)
        m24 = month_or_last(records, 24)

        metrics["month_24_coverage"].append(float(summary["month_24_recurring_cost_coverage"]))
        metrics["final_cash"].append(float(summary["final_operating_cash_usd"]))
        metrics["security_coverage"].append(float(summary["month_24_effective_security_coverage"]))
        metrics["max_sell_ratio"].append(float(summary["maximum_sell_pressure_to_stressed_depth"]))
        metrics["final_domains"].append(float(summary["final_active_domains"]))

        solvent = summary["insolvencyin_mont] is None
        full_fee = summary["month_24_recurring_cost_coverage"] >= float(config["demand"]["month_24_external_fee_coverage"])
        native = bool(m24.native_security_eligible)
        liquid = bool(m24.liquidity_gate)
        domain = bool(summary["domain_concentration_gate"])
        gateicounts["solvent"] += int(solvent)
        gateicounts["month_24_full_fee_coverage"] += int(full_fee)
        gateicounts["native_security_eligible"] += int(native)
        gateicounts["liquidity_gate"] += int(liquid)
        gateicounts["domain_concentration_gate"] += int(domain)
        gateicounts["all_model_gates_except_residuals"] += int(solvent and full_fee and native and liquid and domain)

    def quantiles(values: list[float]) -> dict[str, float]:
        ordered = sorted(values)
        def q(probability: float) -> float:
            if not ordered:
                return 0.0
            position = (len(ordered) - 1) * probability
            lower = math.floor(position)
            upper = math.ceil(position)
            if lower == upper:
                return ordered[lower]
            fraction = position - lower
            return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction
        return {
            "p05": q(0.05),
            "p25": q(0.25),
            "p50": q(0.50),
            "p75": q(0.75),
            "p95": q(0.95),
            "mean": statistics.fmean(ordered),
        }

    return {
        "runs": runs,
        "seed": seed,
        "gateiprobabilities": {name: count / runs for name, count in gateicounts.items()},
        "metric_quantiles": {name: quantiles(values) for name, values in metrics.items()},
        "interpretation": (
            "Probabilities describe this explicit input distribution, not objective launch odds. "
            "Irreversible legal, custody, control and governance gates remain excluded and open."
        ),
    }


def sensitivity(config: Mapping[str, Any]) -> list[dict[str, Any]]:
    tests = [
        ("domain_growth", "monthly_domain_growth_rate", [-0.01, 0.0, 0.02, 0.04, 0.06, 0.08]),
        ("protocol_fee_multiplier", "protocol_fee_multiplier", [0.4, 0.6, 0.8, 1.0, 1.2, 1.5]),
        ("capital_multiplier", "initial_external_capital_multiplier", [0.4, 0.6, 0.8, 1.0, 1.25, 1.5]),
        ("price_multiplier", "price_multiplier", [0.2, 0.3, 0.5, 0.75, 1.0, 1.25]),
        ("depth_multiplier", "depth_multiplier", [0.1, 0.2, 0.4, 0.7, 1.0, 1.5]),
        ("validator_cost_multiplier", "validator_cost_multiplier", [0.75, 1.0, 1.25, 1.5, 1.75, 2.0]),
        ("claim_rate", "claim_rate", [0.25, 0.40, 0.55, 0.70, 0.85, 0.95]),
    ]
    rows: list[dict[str, Any]] = []
    for family, key, values in tests:
        for value in values:
            mutable = json.loads(json.dumps(config))
            mutable["scenarios"]["__sensitivity__"] = {key: value}
            records = simulate(mutable, "native_agent", "__sensitivity__")
            summary = summarize(records, mutable)
            rows.append(
                {
                    "family": family,
                    "parameter": key,
                    "value": value,
                    "month_24_recurring_cost_coverage": summary["month_24_recurring_cost_coverage"],
                    "final_operating_cash_usd": summary["final_operating_cash_usd"],
                    "month_24_effective_security_coverage": summary["month_24_effective_security_coverage"],
                    "maximum_sell_pressure_to_stressed_depth": summary["maximum_sell_pressure_to_stressed_depth"],
                    "native_security_eligiblein_mont: summary["native_security_eligiblein_mont],
                    "insolvencyin_mont: summary["insolvencyin_mont],
                }
            )
    return rows


