"""Monthly scenario simulation engine for IXO-3963."""
from __future__ import annotations

from typing import Any, Mapping

from economic_types import (
    MonthRecord,
    annual_security_cap_tokens,
    apply_unlock_gate,
    current_security_budget,
    initial_capital_ledgers,
    launch_supply_schedule,
    safe_ratio,
    security_haircut_product,
    weighted_sell_fraction,
)

def simulate(
    config: Mapping[str, Any],
    alternative_name: str,
    scenario_name: str,
) -> list[MonthRecord]:
    alt = config["alternatives"][alternative_name]
    scenario = config["scenarios"][scenario_name]
    horizon = int(config["meta"]["horizon_months"])
    security_mode = str(alt["security_mode"])
    native_asset = bool(alt["native_asset"])

    capital = initial_capital_ledgers(config, scenario, alt)
    operating_cash = capital["operating"]
    stable_pol = capital["pol"]
    stable_assurance = capital["assurance"]

    domains = float(config["demand"]["initial_active_external_domains"])
    previous_domains = domains
    external_share = float(config["demand"]["initial_external_payer_share"])
    backlog = 0.0
    minted = 0.0
    transferable = 0.0
    voting = 0.0
    security_reserve_released = 0.0
    annual_security_released: dict[int, float] = {}
    records: list[MonthRecord] = []

    claim_rate = float(scenario.get("claim_rate", config["migration"]["baseline_claim_rate"]))
    price = (
        float(config["liquidity"]["illustrative_initial_price"])
        * float(scenario.get("price_multiplier", 1.0))
    )
    depth = (
        float(config["liquidity"]["monthly_executable_depth_at_5pct"])
        * float(scenario.get("depth_multiplier", 1.0))
    )
    stressed_depth = depth * float(config["liquidity"]["stressed_depth_multiplier"])
    sell_fraction_multiplier = float(scenario.get("sell_fraction_multiplier", 1.0))
    fee_conversion_slippage = float(scenario.get("fee_conversion_slippage_fraction", 0.0))

    largest_controller_share = float(
        scenario.get("largest_controller_share", config["security"]["largest_controller_share"])
    )
    independent_controller_count = int(
        scenario.get("independent_controller_count", config["security"]["independent_controller_count"])
    )
    controllers_to_two_thirds = int(
        scenario.get("controllers_to_two_thirds", config["security"]["controllers_to_two_thirds"])
    )
    largest_domain_share = float(
        scenario.get("largest_domain_revenue_share", config["demand"]["largest_domain_revenue_share"])
    )
    validator_count = int(scenario.get("validator_count", config["security"]["validator_count"]))

    for month in range(1, horizon + 1):
        growth = float(
            scenario.get("monthly_domain_growth_rate", config["demand"]["monthly_domain_growth_rate"])
        )
        churn = float(
            scenario.get("monthly_domain_churn_rate", config["demand"]["monthly_domain_churn_rate"])
        )
        if month > 1:
            previous_domains = domains
            domains = max(domains * (1.0 + growth - churn), 0.0)
        new_domains = max(domains - previous_domains, 0.0)

        active_twins = domains * float(config["demand"]["active_twins_per_domain"])
        gross_agency_value = active_twins * float(config["demand"]["service_value_per_active_twin_month"])
        provider_revenue = gross_agency_value
        gross_protocol_fees = (
            active_twins
            * float(config["demand"]["protocol_fee_per_active_twin_month"])
            * float(scenario.get("protocol_fee_multiplier", 1.0))
            * float(alt.get("protocol_fee_multiplier", 1.0))
        )
        external_share = min(
            external_share + float(config["demand"]["external_payer_share_monthly_improvement"]),
            float(config["demand"]["maximum_external_payer_share"]),
        )
        related_fraction = float(config["demand"]["related_party_fee_fraction"])
        external_protocol_revenue = gross_protocol_fees * external_share * (1.0 - related_fraction)
        related_or_subsidized = gross_protocol_fees - external_protocol_revenue
        external_security_revenue = (
            external_protocol_revenue
            * float(config["demand"]["security_fee_allocation_fraction"])
            * (1.0 - fee_conversion_slippage)
        )
        treasury_fee_revenue = external_protocol_revenue * float(config["demand"]["treasury_fee_allocation_fraction"])
        assurance_fee_revenue = external_protocol_revenue * float(config["demand"]["assurance_fee_allocation_fraction"])
        pol_fee_revenue = external_protocol_revenue * float(config["demand"]["pol_fee_allocation_fraction"])

        # Native AGENT uses shared security during proof; native economics only after the activation month.
        native_security_active = (
            security_mode == "native"
            and month >= int(config["security"]["native_activationin_month"])
      )
        effective_security_mode = security_mode
        if security_mode == "native" and not native_security_active:
            effective_security_mode = "shared"
        security_budget = current_security_budget(
            config, scenario, security_mode=effective_security_mode, alt=alt])
      )

        schedule: dict[str, float]
        if alternative_name in ("native_agent", "shared_security_agent"):
            schedule = launch_supply_schedule(config, month, claim_rate, new_domains)
        elif alternative_name == "recapitalized_ixo":
            schedule = {
                "public": 0.0,
                "pol": 0.0,
                "legacy_immediate": 0.0,
                "legacy_vested": 0.0,
                "contributors": 0.0,
                "strategic": 0.0,
                "adoption": 0.0,
                "treasury": 0.0,
            }
            if month == 1:
                minted = float(alt["legacy_current_supply"])
                transferable = float(alt["legacy_free_supply"])
                voting = transferable
        else:
            schedule = {
                "public": 0.0,
                "pol": 0.0,
                "legacy_immediate": 0.0,
                "legacy_vested": 0.0,
                "contributors": 0.0,
                "strategic": 0.0,
                "adoption": 0.0,
                "treasury": 0.0,
            }

        scheduled_unlock, released_nonpublic, backlog = apply_unlock_gate(
            config,
            schedule,
            backlog,
            price,
            stressed_depth,
            sell_fraction_multiplier,
        )

        if alternative_name in ("native_agent", "shared_security_agent"):
            # POL is minted but locked/non-voting. Public is transferable.
            minted += float(schedule["public"]) + float(schedule["pol"]) + released_nonpublic
            transferable += float(schedule["public"]) + released_nonpublic
            voting += (
                float(schedule["public"])
                + released_nonpublic
                - min(released_nonpublic, float(schedule["adoption"]) + float(schedule["treasury"]))
            )
        elif alternative_name == "recapitalized_ixo":
            monthly_issuance = float(alt["legacy_monthly_issuance_tokens"])
            minted += monthly_issuance
            transferable += monthly_issuance
            voting += monthly_issuance

        security_release_tokens = 0.0
        security_release_stable = 0.0
        security_shortfall = max(security_budget - external_security_revenue, 0.0)
        if native_asset and native_security_active:
            year = (month - 1) // 12
            annual_cap = annual_security_cap_tokens(config, month)
            used = annual_security_released.get(year, 0.0)
            remaining_annual_cap = max(annual_cap - used, 0.0)
            remaining_lifetime = max(
                float(config["supply"]["allocation"]["security_reserve"]) - security_reserve_released,
                0.0,
            )
            conservative_release_price = max(
                price * float(config["security"]["reserve_price_haircut_fraction"]), 1e-9
            )
            if stressed_depth >= float(config["security"]["security_release_pause_if_depth_below_usd"]):
                security_release_tokens = min(
                    security_shortfall / conservative_release_price,
                    remaining_annual_cap,
                    remaining_lifetime,
                )
            security_release_stable = security_release_tokens * conservative_release_price
            annual_security_released[year] = used + security_release_tokens
            security_reserve_released += security_release_tokens
            minted += security_release_tokens
            transferable += security_release_tokens
            voting += security_release_tokens
        elif alternative_name == "recapitalized_ixo":
            # Existing issuance is reported separately from external revenue and is not re-counted here.
            security_release_stable = min(
                security_shortfall,
                float(alt["legacy_monthly_issuance_tokens"]) * price,
            )

        security_cash_shortfall = max(security_shortfall - security_release_stable, 0.0)
        operations_cost = float(config["capital"]["monthly_protocol_operations_cost"])
        implementation_cost = 0.0
        if month <= 18:
            implementation_cost = (
                float(config["capital"]["monthly_implementation_cost_first_18_months"])
                * float(alt.get("implementation_cost_multiplier", 1.0))
            )
        operating_cash += treasury_fee_revenue - operations_cost - implementation_cost - security_cash_shortfall
        stable_assurance += assurance_fee_revenue
        stable_pol += pol_fee_revenue

        recurring_cost = operations_cost + security_budget
        recurring_coverage = safe_ratio(external_protocol_revenue, recurring_cost)
        security_coverage = safe_ratio(external_security_revenue, security_budget)

        if alternative_name == "recapitalized_ixo":
            bonded_tokens = float(alt["legacy_bonded_tokens"])
            largest_controller_for_gate = float(alt["legacy_largest_controller_share"])
            controllers_two_thirds_for_gate = int(alt["legacy_controllers_to_two_thirds"])
        else:
            bonded_tokens = transferable * float(config["security"]["bonded_fraction_of_transferable_supply"])
            largest_controller_for_gate = largest_controller_share
            controllers_two_thirds_for_gate = controllers_to_two_thirds

        lst_underlying = (
            bonded_tokens * float(config["liquidity"]["lst_underlying_cap_fraction_of_bonded"])
            if native_asset
            else 0.0
        )
        haircut = security_haircut_product(config)
        effective_security_capital = bonded_tokens * (price * float(config["liquidity"]["stress_price_multiplier"])) * haircut
        exposure_multiplier = float(scenario.get("open_exposure_multiplier", 1.0))
        mnvar = (
            domains * float(config["security"]["initial_open_critical_exposure_per_domain"]) * exposure_multiplier
            + float(config["security"]["shared_infrastructure_mnvar"])
            + float(config["security"]["bridge_custody_mnvar"])
        )
        effective_security_coverage = safe_ratio(effective_security_capital, mnvar)

        sell_pressure = 0.0
        if native_asset:
            sell_pressure += (
                released_nonpublic
                * weighted_sell_fraction(config, schedule)
                * sell_fraction_multiplier
                * price
            )
            sell_pressure += (
                float(schedule.get("public", 0.0))
                * float(config["liquidity"]["public_follow_on_sell_fraction"])
                * sell_fraction_multiplier
                * price
            )
            sell_pressure += (
                security_release_tokens
                * float(config["liquidity"]["security_release_sell_fraction"])
                * sell_fraction_multiplier
                * price
            )
        sell_ratio = safe_ratio(sell_pressure, stressed_depth)

        concentration_gate = (
            largest_controller_for_gate < float(config["security"]["maximum_largest_controller_share"])
            and independent_controller_count >= int(config["security"]["minimum_independent_controllers"])
            and controllers_two_thirds_for_gate >= int(config["security"]["minimum_controllers_to_two_thirds"])
            and validator_count >= int(config["security"]["minimum_independent_controllers"])
        )
        capital_gate = (
            effective_security_coverage >= float(config["security"]["minimum_effective_security_to_mnvar_ratio"])
        )
        liquidity_gate = (
            sell_ratio <= float(config["liquidity"]["maximum_monthly_sell_pressure_to_stressed_depth"])
            and stressed_depth >= float(config["security"]["security_release_pause_if_depth_below_usd"])
        )
        shared_available = bool(config["security"]["shared_security_provider_concentration_pass"])

        month_fee_gate = True
        if month >= 12:
            month_fee_gate = recurring_coverage >= float(config["demand"]["month_12_external_fee_coverage"])
        if month >= 24:
            month_fee_gate = recurring_coverage >= float(config["demand"]["month_24_external_fee_coverage"])

        native_eligible = (
            native_asset
            and concentration_gate
            and capital_gate
            and liquidity_gate
            and month_fee_gate
            and operating_cash > 0
        )
        # Residual migration/legal/controller gates deliberately prevent irreversible launch.
        irreversible_launch = (
            native_eligible
            and bool(config["migration"]["one_unit_one_claim_gate"])
            and bool(config["migration"]["custodian_reconciliation_gate"])
            and bool(config["migration"]["legal_rights_gate"])
            and bool(config["migration"]["related_party_no_double_benefit_gate"])
        )

        failures: list[str] = []
        if operating_cash < 0:
            failures.append("stable_treasury_insolvent")
        if not concentration_gate and effective_security_mode != "shared":
            failures.append("controller_or_validator_concentration")
        if not capital_gate and effective_security_mode != "shared":
            failures.append("effective_security_undercoverage")
        if not liquidity_gate and native_asset:
            failures.append("liquidity_or_unlock_gate")
        if largest_domain_share > 0.40:
            failures.append("domain_revenue_concentration")
        if recurring_coverage < 0.10 and month >= 12:
            failures.append("external_fee_coverage_below_redesign_gate")
        if not irreversible_launch and month >= int(config["security"]["native_activationin_month":
            failures.append("residual_launch_decisions_open")

        records.append(
            MonthRecord(
                alternative=alternative_name,
                scenario=scenario_name,
                n_mon=month,
                active_external_domains=domains,
                active_twins=active_twins,
                gross_agency_value_usd=gross_agency_value,
                provider_service_revenue_usd=provider_revenue,
                gross_protocol_fees_usd=gross_protocol_fees,
                external_protocol_revenue_usd=external_protocol_revenue,
                external_security_revenue_usd=external_security_revenue,
                related_or_subsidized_fees_usd=related_or_subsidized,
                target_security_budget_usd=security_budget,
                security_reserve_release_tokens=security_release_tokens,
                security_reserve_release_stable_equivalent_usd=security_release_stable,
                security_cash_shortfall_usd=security_cash_shortfall,
                protocol_operations_cost_usd=operations_cost,
                implementation_cost_usd=implementation_cost,
                operating_cash_usd=operating_cash,
                stable_pol_usd=stable_pol,
                stable_assurance_usd=stable_assurance,
                recurring_cost_coverage_ratio=recurring_coverage,
                security_fee_coverage_ratio=security_coverage,
                ninted_supply_tokens=minted if native_asset else 0.0,
                transferable_supply_tokens=transferable if native_asset else 0.0,
                voting_supply_tokens=max(voting, 0.0) if native_asset else 0.0,
                bonded_tokens=bonded_tokens if native_asset else 0.0,
                lst_underlying_tokens=lst_underlying,
                effective_security_capital_usd=effective_security_capital if native_asset else 0.0,
                maximum_network_value_at_risk_usd=mnvar,
                effective_security_coverage_ratio=effective_security_coverage if native_asset else 0.0,
                scheduled_nonpublic_unlock_tokens=scheduled_unlock,
                released_nonpublic_unlock_tokens=released_nonpublic,
                delayed_unlock_backlog_tokens=backlog,
                expected_sell_pressure_usd=sell_pressure,
                stressed_monthly_depth_usd=stressed_depth,
                sell_pressure_to_stressed_depth=sell_ratio,
                largest_controller_share=largest_controller_for_gate,
                independent_controller_count=independent_controller_count,
                controllers_to_two_thirds=controllers_two_thirds_for_gate,
                largest_domain_revenue_share=largest_domain_share,
                native_concentration_gate=concentration_gate,
                native_capital_gate=capital_gate,
                liquidity_gate=liquidity_gate,
                shared_security_available=shared_available,
                native_security_active=native_security_active,
                native_security_eligible=native_eligible,
                irreversible_launch_gate=irreversible_launch,
                failure_flags=";".join(sorted(set(failures))),
            )
        )
    return records
