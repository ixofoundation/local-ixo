"""Core types and deterministic helper formulas for IXO-3963."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping

@dataclass(frozen=True)
class MonthRecord:
    alternative: str
    scenario: str
    month: int
    active_external_domains: float
    active_twins: float
    gross_agency_value_usd: float
    provider_service_revenue_usd: float
    gross_protocol_fees_usd: float
    external_protocol_revenue_usd: float
    external_security_revenue_usd: float
    related_or_subsidized_fees_usd: float
    target_security_budget_usd: float
    security_reserve_release_tokens: float
    security_reserve_release_stable_equivalent_usd: float
    security_cash_shortfall_usd: float
    protocol_operations_cost_usd: float
    implementation_cost_usd: float
    operating_cash_usd: float
    stable_pol_usd: float
    stable_assurance_usd: float
    recurring_cost_coverage_ratio: float
    security_fee_coverage_ratio: float
    minted_supply_tokens: float
    transferable_supply_tokens: float
    voting_supply_tokens: float
    bonded_tokens: float
    lst_underlying_tokens: float
    effective_security_capital_usd: float
    maximum_network_value_at_risk_usd: float
    effective_security_coverage_ratio: float
    scheduled_nonpublic_unlock_tokens: float
    released_nonpublic_unlock_tokens: float
    delayed_unlock_backlog_tokens: float
    expected_sell_pressure_usd: float
    stressed_monthly_depth_usd: float
    sell_pressure_to_stressed_depth: float
    largest_controller_share: float
    independent_controller_count: int
    controllers_to_two_thirds: int
    largest_domain_revenue_share: float
    native_concentration_gate: bool
    native_capital_gate: bool
    liquidity_gate: bool
    shared_security_available: bool
    native_security_active: bool
    native_security_eligible: bool
    irreversible_launch_gate: bool
    failure_flags: str


def deep_get(mapping: Mapping[str, Any], path: str) -> Any:
    current: Any = mapping
    for part in path.split("."):
        current = current[part]
    return current


def ensure_number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    if not math.isfinite(float(value)):
        raise ValueError(f"{name} must be finite")
    return float(value)


def pct(value: float) -> float:
    return round(value * 100.0, 6)


def safe_ratio(numerator: float, denominator: float) -> float:
    if denominator <= 0:
        return math.inf if numerator > 0 else 0.0
    return numerator / denominator


def security_haircut_product(config: Mapping[str, Any]) -> float:
    result = 1.0
    for value in config["security"]["effective_security_haircuts"].values():
        result *= float(value)
    return result


def scenario_value(
    base: Mapping[str, Any],
    scenario: Mapping[str, Any],
    key: str,
    *,
    section: str | None = None,
    default: Any | None = None,
) -> Any:
    if key in scenario:
        return scenario[key]
    if section is not None and key in base[section]:
        return base[section][key]
    return default


def annual_security_cap_tokens(config: Mapping[str, Any], month: int) -> float:
    year_index = min((max(month, 1) - 1) // 12, len(config["supply"]["security_reserve_annual_caps_fraction_of_max"]) - 1)
    return (
        float(config["supply"]["maximum"])
        * float(config["supply"]["security_reserve_annual_caps_fraction_of_max"][year_index])
    )


def linear_vesting(total: float, month: int, cliff: int, vesting_months: int) -> float:
    """Amount newly released in `month`, with first release after the cliff."""
    if month <= cliff or month > cliff + vesting_months:
        return 0.0
    return total / vesting_months


def launch_supply_schedule(
    config: Mapping[str, Any],
    month: int,
    claim_rate: float,
    new_domains: float,
) -> dict[str, float]:
    supply = config["supply"]
    allocation = supply["allocation"]
    result = {
        "public": 0.0,
        "pol": 0.0,
        "legacy_immediate": 0.0,
        "legacy_vested": 0.0,
        "contributors": 0.0,
        "strategic": 0.0,
        "adoption": 0.0,
        "treasury": 0.0,
    }
    if month == 1:
        result["public"] = float(supply["launch_public"])
        result["pol"] = float(supply["launch_pol"])
        result["legacy_immediate"] = (
            float(allocation["legacy_claims"])
            * claim_rate
            * float(supply["legacy_immediate_fraction"])
        )
    follow_on_total = float(allocation["public_capital"]) - float(supply["launch_public"])
    start = int(supply["public_follow_on_start_month"])
    duration = int(supply["public_follow_on_months"])
    if start <= month < start + duration:
        result["public"] += follow_on_total / duration

    legacy_vested_total = (
        float(allocation["legacy_claims"])
        * claim_rate
        * (1.0 - float(supply["legacy_immediate_fraction"]))
    )
    legacy_start = int(supply["legacy_claim_start_month"]) + 1
    legacy_end = legacy_start + int(supply["legacy_vesting_months"]) - 1
    if legacy_start <= month <= legacy_end:
        result["legacy_vested"] = legacy_vested_total / int(supply["legacy_vesting_months"])

    result["contributors"] = linear_vesting(
        float(allocation["contributors"]),
        month,
        int(supply["contributor_cliff_months"]),
        int(supply["contributor_vesting_months"]),
    )
    result["strategic"] = linear_vesting(
        float(allocation["strategic_domains"]),
        month,
        int(supply["strategic_cliff_months"]),
        int(supply["strategic_vesting_months"]),
    )
    result["adoption"] = min(
        max(new_domains, 0.0) * float(supply["adoption_release_per_new_external_domain"]),
        float(supply["adoption_monthly_cap"]),
    )
    return result


def weighted_sell_fraction(config: Mapping[str, Any], schedule: Mapping[str, float]) -> float:
    liquidity = config["liquidity"]
    weighted = 0.0
    total = 0.0
    mapping = {
        "legacy_immediate": "legacy_immediate_sell_fraction",
        "legacy_vested": "legacy_vested_sell_fraction",
        "contributors": "contributor_sell_fraction",
        "strategic": "strategic_sell_fraction",
        "adoption": "strategic_sell_fraction",
        "treasury": "strategic_sell_fraction",
    }
    for name, key in mapping.items():
        amount = float(schedule.get(name, 0.0))
        total += amount
        weighted += amount * float(liquidity[key])
    return weighted / total if total > 0 else 0.0


def apply_unlock_gate(
    config: Mapping[str, Any],
    schedule: Mapping[str, float],
    backlog: float,
    token_price: float,
    stressed_depth: float,
    sell_fraction_multiplier: float,
) -> tuple[float, float, float]:
    scheduled = sum(
        float(schedule.get(key, 0.0))
        for key in ("legacy_immediate", "legacy_vested", "contributors", "strategic", "adoption", "treasury")
    )
    candidate = scheduled + backlog
    expected_sell_fraction = max(
        weighted_sell_fraction(config, schedule) * sell_fraction_multiplier,
        0.01,
    )
    max_sell_usd = (
        stressed_depth
        * float(config["supply"]["max_nonpublic_unlock_fraction_of_stressed_monthly_depth"])
    )
    max_tokens = max_sell_usd / max(token_price * expected_sell_fraction, 1e-9)
    released = min(candidate, max_tokens)
    new_backlog = max(candidate - released, 0.0)
    return scheduled, released, new_backlog


def current_security_budget(
    config: Mapping[str, Any],
    scenario: Mapping[str, Any],
    *,
    security_mode: str,
    alt: Mapping[str, Any],
) -> float:
    security = config["security"]
    if security_mode == "shared":
        return (
            float(security["shared_security_monthly_cost"])
            * float(alt.get("shared_security_cost_multiplier", 1.0))
            * float(scenario.get("validator_cost_multiplier", 1.0))
        )
    validator_count = int(scenario.get("validator_count", security["validator_count"]))
    validator_cost = (
        validator_count
        * float(security["monthly_cost_per_validator"])
        * float(scenario.get("validator_cost_multiplier", 1.0))
        * (1.0 + float(security["validator_margin_fraction"]))
    )
    common = float(security["monthly_common_infrastructure_cost"])
    audit = float(security["monthly_audit_upgrade_incident_cost"])
    return (validator_cost + common + audit) * (1.0 + float(security["decentralisation_premium_fraction"]))


def initial_capital_ledgers(config: Mapping[str, Any], scenario: Mapping[str, Any], alt: Mapping[str, Any]) -> dict[str, float]:
    capital = (
        float(config["capital"]["initial_external_stable_capital"])
        * float(scenario.get("initial_external_capital_multiplier", 1.0))
        * float(alt.get("initial_capital_multiplier", 1.0))
    )
    allocations = config["capital"]["proceeds_allocation"]
    return {
        "gross": capital,
        "operating": capital
        * (
            float(allocations["operations"])
            + float(allocations["security_transition"])
            + float(allocations["implementation"])
            + float(allocations["contingency"])
        )
        - float(alt.get("transition_cost", 0.0)),
        "pol": capital * float(allocations["protocol_owned_liquidity_stable"]),
        "assurance": capital * float(allocations["assurance"]),
    }
