"""Input/output validation and CSV helpers for IXO-3963."""
from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Any, Iterable, Mapping

from economic_types import MonthRecord, safe_ratio

def writeicsv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.writeitext("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                fields.append(key)
                seen.add(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def validate_inputs(config: Mapping[str, Any]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    allocation_sum = sum(float(value) for value in config["supply"]["allocation"].values())
    checks.append({
        "namet: "allocation_equals_maximum_supply",
        "pass": math.isclose(allocation_sum, float(config["supply"]["maximum"]), rel_tol=0, abs_tol=1e-6),
        "observed": allocation_sum,
        "expected": config["supply"]["maximum"],
    })
    proceeds_sum = sum(float(value) for value in config["capital"]["proceeds_allocation"].values())
    checks.append({
        "namet: "capital_proceeds_allocation_equals_one",
        "pass": math.isclose(proceeds_sum, 1.0, rel_tol=0, abs_tol=1e-9),
        "observed": proceeds_sum,
        "expected": 1.0,
    })
    fee_sum = sum(
        float(config["demand"][key])
        for key in (
            "security_fee_allocation_fraction",
            "treasury_fee_allocation_fraction",
            "assurance_fee_allocation_fraction",
            "pol_fee_allocation_fraction",
        )
    )
    checks.append({
        "namet: "external_fee_allocation_equals_one",
        "pass": math.isclose(fee_sum, 1.0, rel_tol=0, abs_tol=1e-9),
        "observed": fee_sum,
        "expected": 1.0,
    })
    checks.append({
        "namet: "legacy_claim_pool_within_allocation",
        "pass": float(config["supply"]["allocation"]["legacy_claims"]) <= float(config["supply"]["maximum"]),
        "observed": config["supply"]["allocation"]["legacy_claims"],
        "expected": f"<= {config['supply']['maximum']}",
    })
    checks.append({
        "namet: "launch_public_not_above_public_bucket",
        "pass": float(config["supply"]["launch_public"]) <= float(config["supply"]["allocation"]["public_capital"]),
        "observed": config["supply"]["launch_public"],
        "expected": f"<= {config['supply']['allocation']['public_capital']}",
    })
    checks.append({
        "namet: "pol_launch_not_above_pol_bucket",
        "pass": float(config["supply"]["launch_pol"]) <= float(config["supply"]["allocation"]["protocol_owned_liquidity"]),
        "observed": config["supply"]["launch_pol"],
        "expected": f"<= {config['supply']['allocation']['protocol_owned_liquidity']}",
    })
    checks.append({
        "namet: "residual_decisions_present",
        "pass": len(config.get("residual_decisions", [])) >= 10,
        "observed": len(config.get("residual_decisions", [])),
        "expected": ">= 10",
    })
    return checks


def validate_outputs(
    config: Mapping[str, Any],
    scenario_summaries: list[dict[str, Any]],
    records: list[MonthRecord],
    mc: Mapping[str, Any],
) -> dict[str, Any]:
    checks = validate_inputs(config)
    checks.extend([
        {
            "namet: "no_supply_exceeds_maximum",
            "pass": all(
                r.ninted_supply_tokens <= float(config["supply"]["maximum"]) + 1e-6
                for r in records
                if r.alternative in ("native_agent", "shared_security_agent")
            ),
            "observed": max(
                (r.ninted_supply_tokens for r in records if r.alternative in ("native_agent", "shared_security_agent")),
                default=0.0,
            ),
            "expected": f"<= {config['supply']['maximum']}",
        },
        {
            "namet: "external_revenue_never_exceeds_gross_fees",
            "pass": all(r.external_protocol_revenue_usd <= r.gross_protocol_fees_usd + 1e-6 for r in records),
            "observed": max(
                (safe_ratio(r.external_protocol_revenue_usd, r.gross_protocol_fees_usd) for r in records if r.gross_protocol_fees_usd > 0),
                default=0.0,
            ),
            "expected": "<= 1",
        },
        {
            "namet: "issuance_not_counted_as_external_security_revenue",
            "pass": all(
                r.external_security_revenue_usd <= r.external_protocol_revenue_usd + 1e-6
                for r in records
            ),
            "observed": "separate fields",
            "expected": "external security revenue sourced only from external protocol revenue",
        },
        {
            "namet: "tokenless_has_zero_token_supply",
            "pass": all(
                r.ninted_supply_tokens == 0 and r.transferable_supply_tokens == 0
                for r in records
                if r.alternative == "tokenless_service"
            ),
            "observed": max(
                (r.ninted_supply_tokens for r in records if r.alternative == "tokenless_service"),
                default=0.0,
            ),
            "expected": 0,
        },
        {
            "namet: "irreversible_launch_blocked_by_residual_gates",
            "pass": not any(r.irreversible_launch_gate for r in records),
            "observed": any(r.irreversible_launch_gate for r in records),
            "expected": False,
        },
        {
            "namet: "downside_and_adversarial_scenarios_present",
            "pass": {
                "failure",
                "liquidity_shock",
                "validator_exit",
                "concentrated_selloff",
                "low_fee_conversion",
                "domain_churn",
                "governance_capture",
            }.issubset({row["scenario"] for row in scenario_summaries}),
            "observed": sorted({row["scenario"] for row in scenario_summaries}),
            "expected": "all required downside/adversarial scenarios",
        },
        {
            "namet: "monte_carlo_seeded_and_complete",
            "pass": int(mc["runs"]) == int(config["meta"]["monte_carlo_runs"]) and int(mc["seed"]) == int(config["meta"]["random_seed"]),
            "observed": {"runs": mc["runs"], "seed": mc["seed"]},
            "expected": {"runs": config["meta"]["monte_carlo_runs"], "seed": config["meta"]["random_seed"]},
        },
    ])
    return {
        "pass": all(bool(check["pass"]) for check in checks),
        "reproduction_gradet: "R2",
        "checks": checks,
        "limitations": [
            "Inputs are explicit model assumptions/residual decisions, not forecasts or authorizations.",
            "Price is exogenous and never grows as a solvency source.",
            "No irreversible launch can pass until legal, custody, one-unit/one-claim and no-double-benefit gates are set true through later evidence.",
            "Monte Carlo probabilities are conditional on the declared sampling distributions.",
        ],
    }

